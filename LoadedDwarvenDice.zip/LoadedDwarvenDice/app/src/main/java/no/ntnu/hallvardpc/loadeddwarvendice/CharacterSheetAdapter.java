package no.ntnu.hallvardpc.loadeddwarvendice;

import android.support.v7.widget.RecyclerView;

/**
 * Created by HallvardPC on 01.11.2017.
 */

/**
public class CharacterSheetAdapter extends RecyclerView.Adapter<CharacterSheetAdapter.MessageViewHolder>
{

}
 */
