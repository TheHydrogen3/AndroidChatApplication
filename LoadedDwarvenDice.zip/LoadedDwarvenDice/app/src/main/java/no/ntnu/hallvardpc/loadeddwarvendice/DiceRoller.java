package no.ntnu.hallvardpc.loadeddwarvendice;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class DiceRoller extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dice_roller);
    }
}
