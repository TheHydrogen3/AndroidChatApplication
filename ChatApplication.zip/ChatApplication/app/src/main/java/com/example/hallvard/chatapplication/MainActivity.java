package com.example.hallvard.chatapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    public static final String CONVERSATION_ID = "com.example.chatapplication.CONVERSATION";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    public void startChat(View view)
    {
        int convName = 0;

        switch(view.getId()){
            case R.id.button1:
                convName = 1;
                break;
            case R.id.button2:
                convName = 2;
                break;
            case R.id.button3:
                convName = 3;
                break;
        }

        Intent intent = new Intent(this, ChatRoomActivity.class);
        intent.putExtra(CONVERSATION_ID, convName);
        startActivity(intent);
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id = item.getItemId();
        switch (id){
            case R.id.action_settings:

                break;
            case R.id.action_login:
                break;
            case R.id.action_log_out:
                finish();
                System.exit(0);
                break;

        }
        return super.onOptionsItemSelected(item);
    }
}
