package com.example.hallvard.chatapplication;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import java.util.List;

/**
 * Created by HallvardPC on 18.10.2017.
 */

class MessageAdapter extends RecyclerView.Adapter<ThumbnailAdapter.ThumbnailViewHolder> {

    List<Message> messages;
    public MessageAdapter(Context context)
    {

    }


    public void setMessages(List<Message> messages) {
        this.messages = messages;
        notifyDataSetChanged();
    }
}
